from lxml import etree
import requests
import csv
import time
from multiprocessing.dummy import Pool as pl
def writecsv(item):
    with open('qfang.csv','a+',encoding='ANSI') as f:
        writer = csv.writer(f)
        try:
            writer.writerow(item)
        except:
            print('write error!')
    
if __name__=='__main__':
    headers1={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) \
    AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'}
    starturl='https://beijing.qfang.com/sale'
    html = requests.get(starturl,headers=headers1)
    time.sleep(2)
    selector=etree.HTML(html.text)
    houselist=selector.xpath('//*[@id="cycleListings"]/ul/li')
    for house in houselist:
        housetitle=house.xpath('div[1]/p[1]/a/text()')[0]
        houseinformation = house.xpath('div[1]/p[2]/text()')[0]
        houseaddress=house.xpath('div[1]/p[3]/text()')[0]
        houseprice = house.xpath('div[2]/span[1]/text()')[0]
        priceunit = house.xpath('div[2]/span[2]/text()')[0]
        item = [housetitle,houseinformation,houseaddress,houseprice,priceunit]
        writecsv(item)
        print('正在抓取:',housetitle)


